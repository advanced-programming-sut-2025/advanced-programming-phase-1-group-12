package models.NPC;

import models.Place.Place;

import java.util.ArrayList;

public class NPCvillage implements Place {
    ArrayList<NPC> NPCs = new ArrayList<>();
}
