package models.RelatedToUser;

public class Ability {
    private int farming;
    private int fishing;
    private int mining;
    private int searching;

}
