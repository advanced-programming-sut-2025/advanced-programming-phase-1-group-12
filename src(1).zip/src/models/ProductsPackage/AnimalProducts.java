package models.ProductsPackage;


public class AnimalProducts implements Products {

}
