package models;

import models.enums.ToolEnums.ToolTypes;

public class Tools {
    private ToolTypes type;
    private String name;
    public Tools(ToolTypes type, String name) {
        this.type = type;
        this.name = name;
    }
}
