package models.Fundementals;

public record Result(String message, boolean success) {
}
