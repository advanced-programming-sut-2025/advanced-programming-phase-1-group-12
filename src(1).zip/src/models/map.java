package models;

import models.Fundementals.Location;
import models.NPC.NPCvillage;
import models.Place.Farm;
import models.Place.Store;

import java.util.*;

public class map {
    private int mapNumber;

    private ArrayList<Farm> farms = new ArrayList<>();

    private ArrayList<Location>allLocations = new ArrayList<>();

    private List<Store> allStores = new ArrayList<>();

    public ArrayList<NPCvillage>NPC;

    public int getMapNumber() {
        return mapNumber;
    }

    public void setMapNumber(int mapNumber) {
        this.mapNumber = mapNumber;
    }

    public ArrayList<Farm> getFarms() {
        return farms;
    }

    public void setFarms(ArrayList<Farm> farms) {
        this.farms = farms;
    }

    public ArrayList<Location> getAllLocations() {
        return allLocations;
    }

    public void setAllLocations(ArrayList<Location> allLocations) {
        this.allLocations = allLocations;
    }

    public List<Store> getAllStores() {
        return allStores;
    }

    public void setAllStores(List<Store> allStores) {
        this.allStores = allStores;
    }

    public ArrayList<NPCvillage> getNPC() {
        return NPC;
    }

    public void setNPC(ArrayList<NPCvillage> NPC) {
        this.NPC = NPC;
    }
}
