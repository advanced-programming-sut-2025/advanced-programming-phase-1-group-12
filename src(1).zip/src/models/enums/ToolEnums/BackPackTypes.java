package models.enums.ToolEnums;

public enum BackPackTypes {
    PRIMARY,
    BIG,
    DELUXE
}
