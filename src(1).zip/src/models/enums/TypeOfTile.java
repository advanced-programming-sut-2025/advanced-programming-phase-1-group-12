package models.enums;

public enum TypeOfTile {
    LAKE,

    TREE;


}
