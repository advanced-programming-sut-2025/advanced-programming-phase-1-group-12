package models;

import models.enums.Season;

import java.util.Arrays;
import java.util.List;

public class Weather {
    private String name;
    private List<Season> seasons;

    public Weather(String name, List<Season> season) {
        this.name = name;
        this.seasons = season;
    }

    public String getName() {
        return name;
    }
    public List<Season> getSeasons() {
        return seasons;
    }
    public void addSeason(Season season) {
        seasons.add(season);
    }

}
