package controller.MapSetUp;

import models.Fundementals.Location;
import models.MapDetails.GreenHouse;
import models.MapDetails.Lake;
import models.MapDetails.Quarry;
import models.MapDetails.Shack;

import java.util.ArrayList;

public class FarmSetUp {
    public Lake lakeSetUp(Location.LocationOfRectangle location) {
        Lake lake = new Lake();
        return lake;
    }

    public GreenHouse greenHouseSetUp(Location.LocationOfRectangle location) {
        GreenHouse greenHouse = new GreenHouse();
        return greenHouse;
    }

    public Shack shackSetUp(GreenHouse location) {
        return new Shack();
    }

    public Quarry quarrySetUp(Location.LocationOfRectangle location) {return new Quarry();}

    public ArrayList<Location> randomForaging() {return  new ArrayList<>();}

    public void setForagingTypes(ArrayList<Location> locations) {}


}
