package controller;

import models.Fundementals.Location;
import models.Fundementals.Result;

import java.util.ArrayList;

public class WeatherController {
    public Result showCurrentWeather() {
        return Result.success("");
    }
    public Result weatherForecast() {
        return Result.success("");
    }
    public Result cheatWeatherSet(){
        return Result.success("");
    }
    public void greenhouseBuild(){}

    public boolean checkGreenhouseCondition() {
        return false;
    }

    public void enterNextDay(){}
    public void strikeThunder(ArrayList<Location> locations) {}
    public void chooseLocation(){}
    public ArrayList<Location> randomThreeLocationsThunder(){return null;}
}
