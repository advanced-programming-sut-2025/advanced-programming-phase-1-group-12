package models.MapDetails;

public enum Stones {
    KANI,

    AHAN,

    NORMAL;
}
