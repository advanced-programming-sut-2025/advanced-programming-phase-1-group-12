package models;

import models.RelatedToUser.User;

import java.util.ArrayList;

public class App {
    private static ArrayList<Game> allGames;

    private static Game currentGame;
}
