package models.enums.Types;

public enum TypeOfTile {
    LAKE,
    GREENHOUSE,
    HOUSE,
    TREE;


}
