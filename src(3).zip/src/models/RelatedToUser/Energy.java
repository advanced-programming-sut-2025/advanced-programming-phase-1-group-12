package models.RelatedToUser;

public class Energy {
    private int energy;
    private int maxEnergy= 200;
    public Energy(int energy) {
        this.energy = energy;
    }
}
