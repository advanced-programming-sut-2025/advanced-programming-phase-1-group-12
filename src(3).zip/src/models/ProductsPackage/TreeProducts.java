package models.ProductsPackage;

public class TreeProducts implements Products{
}
