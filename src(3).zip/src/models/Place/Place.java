package models.Place;

import models.Fundementals.Location;

public interface Place {
    Location.LocationOfRectangle locationOfRectangle();
}
