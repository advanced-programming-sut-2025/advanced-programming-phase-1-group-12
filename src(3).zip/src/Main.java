import views.AppViews;

public class Main {
    public static void main(String[] args) {
        (new AppViews()).run();
    }
}