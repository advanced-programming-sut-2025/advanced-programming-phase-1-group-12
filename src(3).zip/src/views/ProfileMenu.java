package views;

import java.util.Scanner;

public class ProfileMenu extends AppMenu{

    @Override
    public void check(Scanner scanner) {

    }
}
