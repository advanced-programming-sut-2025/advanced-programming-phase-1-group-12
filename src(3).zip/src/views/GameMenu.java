package views;

import java.util.Scanner;
public class GameMenu extends AppMenu {
    @Override
    public void check(Scanner scanner) {

    }
    public void showCurrentTime(){}
    public void showCurrentDate(){}
    public void showCurrentSeason(){}
    public void dateTime(){}
    public void dayOfWeek(){}
    public void cheatAdvancedTime(){}
    public void cheatAdvancedDate(){}

}
