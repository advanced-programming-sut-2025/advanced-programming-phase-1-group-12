package controller;

import models.RelationShip;
import models.Fundementals.Result;
import models.RelatedToUser.User;

public class RelationshipController {
    public void trade(String input){

    }
    public Result buyGift(User user, RelationShip result ) {
        return null;
    }
    public void giftList(){}

    public void hug(){}

    public Result askMarriage(RelationShip result, String ring, User user){}

    public Result respondMarriageRequest(RelationShip result, String ring){}

    public void startTrade(){}

    public Result tradeRespond(){return null;}

    public void respondTotrade(RelationShip.Trade trade){}

    public void giftrate(RelationShip.Gift gift, int rate){}

    public void showTrade(){}
}

