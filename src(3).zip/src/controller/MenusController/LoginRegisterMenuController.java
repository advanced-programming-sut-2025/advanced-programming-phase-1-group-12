package controller.MenusController;

import models.Fundementals.Result;
import models.RelatedToUser.User;

public class LoginRegisterMenuController implements MenuController {
    public String RandomPassword(String input) {}

    public Result register(String username, String password) {}

    public Result login(String username, String password) {}

    public Result pickQuestion(String inout){}

    public void saveSecureHashAlgorithm(String inout){}

    public User checkUserName(String userName){}
}
