package controller.MapSetUp;

public class MapInfo {

}
