package controller.MapSetUp;

import models.Fundementals.Location;
import models.MapDetails.GreenHouse;
import models.MapDetails.Lake;
import models.MapDetails.Quarry;
import models.MapDetails.Shack;

import java.util.ArrayList;
import java.util.List;

public class FarmSetUp {

}
