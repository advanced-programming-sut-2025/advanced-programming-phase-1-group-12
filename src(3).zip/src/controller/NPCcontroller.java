package controller;
import models.*;

import models.Fundementals.Location;
import models.NPC.NPC;

public class NPCcontroller {

    public boolean canSpeak(Location location1, Location location2){return false;}

    public void meetNPC(NPC npc){}

    public void giftNPC(NPC npc, RelationShip.Gift gift){}

    public void handleMissions(){}

}
