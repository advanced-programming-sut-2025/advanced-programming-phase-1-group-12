package views;

import java.util.Scanner;

public class MainMenu extends AppMenu{
    @Override
    public void check(Scanner scanner) {

    }
}
