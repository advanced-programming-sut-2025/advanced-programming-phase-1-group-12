package views;

import java.util.Scanner;

public class GameMenu extends AppMenu {
    @Override
    public void check(Scanner scanner) {

    }
}
