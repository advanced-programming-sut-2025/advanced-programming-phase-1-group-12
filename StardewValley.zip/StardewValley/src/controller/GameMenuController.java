package controller;

public interface GameMenuController {
}
