package controller;

public class MinMenuController {
}
