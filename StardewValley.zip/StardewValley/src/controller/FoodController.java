package controller;

import models.Eating.Food;
import models.Eating.Recipes;
import models.Fundementals.Result;
import models.RelatedToUser.User;

public class FoodController {

    public Result put_pick(Food newFood){ return null;}

    public Result showRecipes(User user){ return null;}

    public Result prepareFood(Recipes recipes){return null;}

    public Result eatFood(String nameFood){return null;}

}
