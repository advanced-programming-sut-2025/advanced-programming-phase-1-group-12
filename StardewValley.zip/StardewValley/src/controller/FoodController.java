package controller;

import models.Food;
import models.Recipes;
import models.Result;
import models.User;

public class FoodController implements GameMenuController{

    public Result put_pick(Food newFood){ return null;}

    public Result showRecipes(User user){ return null;}

    public Result prepareFood(Recipes recipes){return null;}

    public Result eatFood(String nameFood){return null;}

}
