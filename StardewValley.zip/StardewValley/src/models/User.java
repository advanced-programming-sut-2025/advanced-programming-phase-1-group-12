package models;

import java.util.ArrayList;

public class User {
    private ArrayList<Recipes> recipes = new ArrayList<>();
    private int Energy;

    public ArrayList<Recipes> getRecipes() {
        return recipes;
    }

    public void setRecipes(ArrayList<Recipes> recipes) {
        this.recipes = recipes;
    }

    public void addRecipes (Recipes newRecipes){
        recipes.add(newRecipes);
    }

    public int getEnergy() {
        return Energy;
    }

    public void setEnergy(int energy) {
        Energy = energy;
    }
}
