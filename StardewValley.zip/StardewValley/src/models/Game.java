package models;

import java.util.HashMap;
import java.util.Map;

public class Game {
}
