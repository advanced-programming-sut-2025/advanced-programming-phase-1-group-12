package models.enums;

public enum CraftingRecepie {
//    Cherry Bomb
//            Bomb
//    Mega Bomb
//    Sprinkler
//    Quality Sprinkler
//    Iridium Sprinkler
//    Charcoal Klin
//    Furnace
//            Scarecrow
//    Deluxe Scarecrow
//    Bee House
//    Cheese Press
//    Keg
//            Loom
//    Mayonnaise Machine
//    Oil Maker
//    Preserves Jar
//    Dehydrator
//    Fish Smoker
//    Mystic Tree Seed
}
