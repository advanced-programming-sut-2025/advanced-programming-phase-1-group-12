package models.enums;

public enum Season {
    SPRING,
    SUMMER,
    AUTUMN,
    WINTER
}
