package models.enums;

public enum LoginRegisterMenuCommands {

}
