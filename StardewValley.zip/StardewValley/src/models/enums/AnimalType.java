package models.enums;

public enum AnimalType {
    COOP,
    BARN
}
