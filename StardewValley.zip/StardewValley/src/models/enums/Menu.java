package models.enums;

import views.*;
import java.util.*;

public enum Menu {
    LoginRegisterMenu(new LoginRegisterMenu()),
    MainMenu(new MainMenu()),
    GameMenu(new GameMenu()),
    PROFILEMENU(new ProfileMenu()),
    Exit(new ExitMenu());

    public final AppMenu menu;

    Menu(AppMenu menu) {
        this.menu = menu;
    }
    public void checkCommand(Scanner scanner) {
        this.menu.check(scanner);
    }
}
