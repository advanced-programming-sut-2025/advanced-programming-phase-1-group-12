package models.MapDetails;

import models.Fundementals.Location;
import models.Place.Place;

public class Lake implements Place {
     Location.LocationOfRectangle lakeLocation;

     public Location.LocationOfRectangle getLakeLocation() {
          return lakeLocation;
     }

     public void setLakeLocation(Location.LocationOfRectangle lakeLocation) {
          this.lakeLocation = lakeLocation;
     }
}
