package models.Place;

import models.MapDetails.*;
import models.RelatedToUser.User;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Farm implements Place {
    private Map<TreesTypes, Integer> trees = new HashMap<>();

    private Map<Stones, Integer> stones = new HashMap<>();

    private Shack shack;

    private GreenHouse greenHouse;

    private Quarry quarry;

    private ArrayList<Lake> lakes = new ArrayList<>();

    private ArrayList<User> owners = new ArrayList<>();

    public Map<TreesTypes, Integer> getTrees() {
        return trees;
    }

    public void setTrees(Map<TreesTypes, Integer> trees) {
        this.trees = trees;
    }

    public Map<Stones, Integer> getStones() {
        return stones;
    }

    public void setStones(Map<Stones, Integer> stones) {
        this.stones = stones;
    }

    public Shack getShack() {
        return shack;
    }

    public void setShack(Shack shack) {
        this.shack = shack;
    }

    public GreenHouse getGreenHouse() {
        return greenHouse;
    }

    public void setGreenHouse(GreenHouse greenHouse) {
        this.greenHouse = greenHouse;
    }

    public Quarry getQuarry() {
        return quarry;
    }

    public void setQuarry(Quarry quarry) {
        this.quarry = quarry;
    }

    public ArrayList<Lake> getLakes() {
        return lakes;
    }

    public void setLakes(ArrayList<Lake> lakes) {
        this.lakes = lakes;
    }

    public ArrayList<User> getOwners() {
        return owners;
    }

    public void setOwners(ArrayList<User> owners) {
        this.owners = owners;
    }
}
