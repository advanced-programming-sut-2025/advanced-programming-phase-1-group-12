package models;

import models.enums.ProductType;

public class Products {
    private String name;
    private ProductType type;

    public Products(String name, ProductType type){
        this.name = name;
        this.type = type;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setType(ProductType type) {
        this.type = type;
    }

    public ProductType getType() {
        return type;
    }
}
