package controller;

import models.Craft;
import models.Fundementals.Result;

public class CraftingController {
    public Result showRecipes(){
        return null;
    }
    public Craft makingCraft(String itemName){return new Craft();}
    public void placeItem(String itemName, String direction){}
    public void addItem(String itemName, int count){}
    public Result showCraftInto(Craft craftItem){
        return null;
    }
}
