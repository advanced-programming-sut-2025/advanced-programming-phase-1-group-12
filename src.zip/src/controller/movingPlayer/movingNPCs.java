package controller.movingPlayer;

public class movingNPCs {
}
