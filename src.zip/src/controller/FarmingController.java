package controller;

import models.Fundementals.Result;

public class FarmingController {
    public void plow(){}
    public void plantSeed(String seed, String direction){}
    public Result showPlant(){
        return null;
    }
    public void fertilizePlant(String seed, String direction){}
    public Result howMuchWater(){
        return null;
    }
    public void waterPlant(String seed, String direction){}
    public void harvestPlant(String seed, String direction){}
}
