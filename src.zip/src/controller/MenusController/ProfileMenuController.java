package controller.MenusController;

import models.Fundementals.Result;

public class ProfileMenuController implements MenuController {

    public Result changeUserName(String message){

    }

    public Result changeNickname(String message){

    }

    public Result changePassword(String message){}

    public Result userInfo(){}
}
