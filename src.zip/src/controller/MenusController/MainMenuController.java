package controller.MenusController;

public class MainMenuController implements MenuController {
    public void logOut(){}


}
