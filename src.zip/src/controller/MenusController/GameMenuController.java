package controller.MenusController;

import models.RelatedToUser.User;
import models.Fundementals.Result;
import models.*;

import java.util.Map;

public class GameMenuController implements MenuController {
    Game currentMap =
    public Result newGame() { return null;}

    public map choosingMap(int MapId){ return null;}

    public Result loadGame(){ return null;}

    public void savingMap(Map<map, User>userAndTheirMap){}

    public Result deleteGame(int MapId){ return null;}

    public void nextTurn(){ }

    //TODO:sper chiz ro bezanim baraye geragten babash

    public void readingMap(){ }

    public void energyUnlimited(){}

    public Result sellProducts(String productName, int Count){
        return null;
    }

    public void tradeHistory(User user){}

    public void printMap(int x, int y, int size){
    }
}
