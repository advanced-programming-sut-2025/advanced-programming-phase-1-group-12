package controller.MenusController;

import models.Fundementals.Location;
import models.RelatedToUser.User;
import models.Fundementals.Result;
import models.*;
import models.enums.Menu;

import java.util.*;

public class GameMenuController implements MenuController {

    Game currentGame = App.getCurrentGame();

    public Result newGame() { return null;}

    public map choosingMap(int MapId){ return null;}

    public Result loadGame(){ return null;}

    public void savingMap(Map<map, User>userAndTheirMap){}

    public Result deleteGame(int MapId){ return null;}

    public void nextTurn(){ }

    //TODO:super chiz ro bezanim baraye generate babash

    public void readingMap(){ }

    public void energyUnlimited(){}

    public Result sellProducts(String productName, int Count){
        return null;
    }

    public void tradeHistory(User user){}

    public void printMap(int x, int y, int size) {
        for (int X = x; X < x + size; X++) {
            for (int Y = y; Y < y + size; Y++) {
                Location currentLocation = currentGame.getMainMap().findLocation(X, Y);
                System.out.print(currentLocation.getTypeOfTile().getNameOfMap()+ " ");
            }
            System.out.println(); // Move to next line after each row
        }
    }


    public Result Play(Scanner scanner, List<String> usernames) {

        ArrayList<User> players = new ArrayList<>();
        players.add(App.getLoggedInUser());
        for (String username : usernames) {
            if (username != null) {
                User user = App.getUserByUsername(username.trim());
                if (user != null)
                    players.add(user);
                
            }
        }


        return new Result(true, "");
    }
}
