package controller;

import models.Fundementals.Result;

public class DateController {
    public Result showCurrentTime() {
        return Result.success("");
    }
    public Result showCurrentDate(){
        return Result.success("");
    }
    public Result showCurrentSeason(){
        return Result.success("");
    }
    public Result dateTime(){
        return Result.success("");
    }
    public Result dayOfWeek(){
        return Result.success("");
    }
    public Result cheatAdvancedTime(){
        return Result.success("");
    }
    public Result cheatAdvancedDate(){
        return Result.success("");
    }

    public void changeTime(){}
    public void changeDate(){}
    public void changeSeason(){}


}
