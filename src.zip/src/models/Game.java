package models;

import models.RelatedToUser.User;

import java.util.ArrayList;
import java.util.Map;

public class Game {
    private static Date date;
    private map mainMap;
    private ArrayList<User> gameUsers;
    private Map<User, Integer> score;

    public map getMainMap() {
        return mainMap;
    }
}
