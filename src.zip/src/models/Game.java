package models;

import models.RelatedToUser.User;

import java.util.ArrayList;
import java.util.Map;

public class Game {
    private static Date date;
    private map map;
    private ArrayList<User> gameUsers;
    private Map<User, Integer> score;


}
