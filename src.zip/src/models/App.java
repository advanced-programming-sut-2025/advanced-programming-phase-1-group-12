package models;

import models.RelatedToUser.User;
import models.enums.Menu;

import java.util.ArrayList;

public class App {
    private static ArrayList<User> player;

    private static ArrayList<Game> allGames;

    private static Game currentGame;

    private static User loggedInUser;

    private static Menu currentMenu = Menu.MainMenu;

    public static Game getCurrentGame() {
        return currentGame;
    }

    public static User getUserByUsername(String username) {
        for(User user : player){
            if(user.getUserName().equals(username))
                return user;
        }
        return null;
    }

    public void setLoggedInUser(User loggedInUser) {
        this.loggedInUser = loggedInUser;
    }

    public static void setCurrentGame(Game currentGame) {
        App.currentGame = currentGame;
    }

    public static User getLoggedInUser() {
        return loggedInUser;
    }

    public ArrayList<Game> getAllGames() {
        return allGames;
    }

    public Menu getCurrentMenu() {
        return currentMenu;
    }

    public void setAllGames(ArrayList<Game> allGames) {
        this.allGames = allGames;
    }

    public void setCurrentMenu(Menu currentMenu) {
        this.currentMenu = currentMenu;
    }
}
