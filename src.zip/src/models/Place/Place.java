package models.Place;

import models.Fundementals.LocationOfRectangle;

public interface Place {
    LocationOfRectangle locationOfRectangle();
}
