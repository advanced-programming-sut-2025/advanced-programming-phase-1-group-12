package models.ProductsPackage;

public class StoreProducts implements Products{
}
