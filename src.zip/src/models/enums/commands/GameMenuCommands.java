package models.enums.commands;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum GameMenuCommands implements Commands {
    PLAY("^\\s*game new -u (?:\\s+(\\w+))?(?:\\s+(\\w+))?(?:\\s+(\\w+))?\\s*$"),

    LoadGame(""),

    ExitGame(""),

    NextTurn(""),

    Walk("");

    private final String pattern;

    GameMenuCommands(String pattern) {
        this.pattern = pattern;
    }

    @Override
    public Matcher getMather(String input) {
        Matcher matcher = Pattern.compile(this.pattern).matcher(input);

        if (matcher.matches()) return matcher;
        return null;
    }

}
