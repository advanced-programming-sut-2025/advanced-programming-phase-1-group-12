package models.enums;

public enum NPCdetails {
}
