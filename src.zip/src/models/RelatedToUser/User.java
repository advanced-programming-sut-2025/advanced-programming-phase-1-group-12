package models.RelatedToUser;

import models.*;
import models.Fundementals.Location;
import models.MapDetails.Shack;

import java.util.ArrayList;

public class User {
    private ArrayList<Game> games;
    private String userName;

    private String password;

    private String email;

    private String questionForSecurity;

    private String answerOfQuestionForSecurity;

    private Location userLocation;

    private Shack shack;

    private map map;

    private boolean isMarried;

    private Energy energy;

    public Refrigrator Refrigrator = new Refrigrator();

    private ArrayList<Ability> abilitis = new ArrayList <Ability>();

    private int count =0;

    private ArrayList<RelationShip> relationShips = new ArrayList<>();

    private ArrayList<RelationShip.Trade>trade = new ArrayList<>();

    public void collapse(){}

    public Shack getShack() {
        return shack;
    }

    public ArrayList<Ability> getAbilitis() {
        return abilitis;
    }

    public ArrayList<Game> getGames() {
        return games;
    }

    public ArrayList<RelationShip.Trade> getTrade() {
        return trade;
    }

    public boolean isMarried() {
        return isMarried;
    }

    public String getEmail() {
        return email;
    }

    public Energy getEnergy() {
        return energy;
    }

    public Location getUserLocation() {
        return userLocation;
    }

    public map getMap() {
        return map;
    }

    public String getUserName() {
        return userName;
    }

    public int getCount() {
        return count;
    }

    public ArrayList<RelationShip> getRelationShips() {
        return relationShips;
    }

    public Refrigrator getRefrigrator() {
        return Refrigrator;
    }

    public String getPassword() {
        return password;
    }

    public String getAnswerOfQuestionForSecurity() {
        return answerOfQuestionForSecurity;
    }

    public String getQuestionForSecurity() {
        return questionForSecurity;
    }

    public void setAbilitis(ArrayList<Ability> abilitis) {
        this.abilitis = abilitis;
    }

    public void setAnswerOfQuestionForSecurity(String answerOfQuestionForSecurity) {
        this.answerOfQuestionForSecurity = answerOfQuestionForSecurity;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setEnergy(Energy energy) {
        this.energy = energy;
    }

    public void setGames(ArrayList<Game> games) {
        this.games = games;
    }

    public void setMap(map map) {
        this.map = map;
    }

    public void setMarried(boolean married) {
        isMarried = married;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setQuestionForSecurity(String questionForSecurity) {
        this.questionForSecurity = questionForSecurity;
    }

    public void setRefrigrator(Refrigrator refrigrator) {
        Refrigrator = refrigrator;
    }

    public void setRelationShips(ArrayList<RelationShip> relationShips) {
        this.relationShips = relationShips;
    }

    public void setShack(Shack shack) {
        this.shack = shack;
    }

    public void setUserLocation(Location userLocation) {
        this.userLocation = userLocation;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setTrade(ArrayList<RelationShip.Trade> trade) {
        this.trade = trade;
    }
}
