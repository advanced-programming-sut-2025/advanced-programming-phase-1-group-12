package models.Animal;

import models.ProductsPackage.Products;

public interface Animals {
     String name = "" ;

     int price = 0;
}
