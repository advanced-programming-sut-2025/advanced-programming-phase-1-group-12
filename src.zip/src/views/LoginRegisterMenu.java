package views;

import java.util.Scanner;

public class LoginRegisterMenu extends AppMenu{
    @Override
    public void check(Scanner scanner) {

    }
}
