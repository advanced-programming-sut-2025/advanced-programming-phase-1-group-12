package views;

import java.util.Scanner;

public class ExitMenu extends AppMenu{
    @Override
    public void check(Scanner scanner) {}
}
