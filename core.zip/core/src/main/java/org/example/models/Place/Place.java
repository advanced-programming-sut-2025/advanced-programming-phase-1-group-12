package org.example.models.Place;

import org.example.models.Fundementals.LocationOfRectangle;

public interface Place {
    LocationOfRectangle getLocation ();
}
