package org.example.models.MapDetails;

public enum Stones {
    KANI,

    AHAN,

    NORMAL;
}
